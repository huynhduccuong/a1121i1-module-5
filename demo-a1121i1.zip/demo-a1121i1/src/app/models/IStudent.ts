export interface IStudent{
  id: number;
  name: string;
  address: string;
  age: number;
  avatar?: string;
  mark: number
}
