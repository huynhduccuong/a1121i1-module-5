import {Component, Input, OnInit} from '@angular/core';
import {IStudent} from "../models/IStudent";
import {StudentServiceService} from "../student-service.service";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent implements OnInit {

  student: IStudent | undefined;
  constructor(private studentService: StudentServiceService,
              private activedRouter: ActivatedRoute) { }

  ngOnInit(): void {
    this.activedRouter.paramMap.subscribe((param) => {
      const id = parseInt(<string>param.get('id'));
      this.student = this.studentService.findByID(id);
    })

  }

}
