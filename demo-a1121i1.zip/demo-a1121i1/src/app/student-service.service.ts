import { Injectable } from '@angular/core';
import {IStudent} from "./models/IStudent";
import {StudentDao} from "./data/StudentDao";

@Injectable({
  providedIn: 'root'
})
export class StudentServiceService {

  constructor() { }

  createStudent(student: IStudent){
    StudentDao.students.unshift(student);
  }

  editStudent(){

  }
  deleteStudent(student: IStudent){
    // StudentDao.students.;
  }

  getAllStudent(){
    return StudentDao.getAllStudent();
  }

  findByID(id: number){
    return StudentDao.students.find((stud) => stud.id == id);
  }
}
