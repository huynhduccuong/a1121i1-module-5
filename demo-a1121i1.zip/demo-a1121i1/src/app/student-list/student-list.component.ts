import {Component, OnInit} from '@angular/core';
import {IStudent} from "../models/IStudent";
import {StudentDao} from "../data/StudentDao";
import {StudentServiceService} from "../student-service.service";

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  listStudent: IStudent[] = [];
  detailStudent: IStudent | undefined;
  constructor(private studentService: StudentServiceService) {
  }

  ngOnInit(): void {
    this.listStudent = this.studentService.getAllStudent();
  }

  changeStudent(student: IStudent) {
    this.detailStudent = student;
  }

  deleteStudent(student: IStudent) {
    this.studentService.deleteStudent(student);
  }
}
