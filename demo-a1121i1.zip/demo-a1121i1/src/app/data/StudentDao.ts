import {IStudent} from "../models/IStudent";

export class StudentDao{
  static students: IStudent[] = [
    {
      id: 10,
      name: "hoàng Long",
      address: "Quảng Nam",
      age: 20,
      avatar: "https://t4.ftcdn.net/jpg/03/85/50/01/360_F_385500115_T8QiYsPeliQ5tE3npwOuJNUfunqFBo1U.jpg",
      mark: 9
    },
    {
      id: 11,
      name: "ĐỨC Cường",
      address: "Quảng Nam",
      age: 27,
      avatar: "",
      mark: 4
    },
    {
      id: 13,
      name: "đăng hiếu",
      address: "Đà Nẵng",
      age: 25,
      avatar: "",
      mark: 5
    },
    {
      id: 14,
      name: "PHƯƠNG NHI",
      address: "Gia Lai",
      age: 21,
      avatar: "",
      mark: 7
    }
  ]

  static getAllStudent() {
    return this.students;
  }

}
